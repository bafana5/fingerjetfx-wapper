﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using libFjfx;
using System.IO;
using System.Runtime.InteropServices;
using System.Collections;
using codeding.Imaging;
using System.Drawing;



namespace CSApplication
{
    public partial class Program
    {
        static void Main(string[] args)
        {
           

            PGM pgm = PGM.ReadFromBitmap((Bitmap)Bitmap.FromFile(@"Right_Middle.bmp"));
            byte[] b = pgm.GetPixelData();
           
            ISO_ANSI_PARAM P = new ISO_ANSI_PARAM(60, 0, 0);
            uint dpi = 500;
            uint width = (uint)pgm.Size.Width;
            uint height = (uint)pgm.Size.Height;

            FJFXWrapper c = new FJFXWrapper();

            {
                Result Ansi_null = c.CreateANSIFeatureSetFromRaw(b, dpi,width,height);
                byte[] Ansi_null_bytes = Ansi_null.GetData();
                SaveBytes("Ansi_null_bytes", Ansi_null_bytes);
            }
            {
                Result Ansi = c.CreateANSIFeatureSetFromRaw(b, dpi, width, height, P);
                byte[] Ansi_bytes = Ansi.GetData();
                SaveBytes("Ansi_bytes", Ansi_bytes);
            }
            {
                Result ISO = c.CreateISOFeatureSetFromRaw(b, dpi, width, height, P);
                byte[] ISO_bytes = ISO.GetData();
                SaveBytes("ISO_bytes", ISO_bytes);
            }

            {
                Result ISO_null = c.CreateISOFeatureSetFromRaw(b, dpi, width, height);
                byte[] ISO_null_bytes = ISO_null.GetData();
                SaveBytes("ISO_null_bytes", ISO_null_bytes);
            }

        }
       

     

        private static void SaveBytes(string File, byte[] res1)
        {

            StreamWriter s = new StreamWriter(File,false);
            BinaryWriter w = new BinaryWriter(s.BaseStream);

            w.Write(res1, 0, res1.Length);

            w.Close();

          
        }

        private static byte[] GetBytes(string File)
        {
            StreamReader reader = new StreamReader(File, false);


            var bytes = default(byte[]);
            using (var memstream = new MemoryStream())
            {
                var buffer = new byte[512];
                var bytesRead = default(int);
                while ((bytesRead = reader.BaseStream.Read(buffer, 0, buffer.Length)) > 0)
                    memstream.Write(buffer, 0, bytesRead);
                bytes = memstream.ToArray();
            }

            reader.Close();

            return bytes;

        }
        //private static string Get6()
        //{
        //    StreamReader W = new StreamReader(@"Bytes.txt", false);
        //    string TestAnsiImage = W.ReadToEnd();
        //    W.Close();
        //    return TestAnsiImage;

        //}
        //private static byte[] _Get()
        //{
        //    List<byte> a = new List<byte>();



        //    using (StreamReader R = new StreamReader(@"TextFile1.txt"))
        //    {
        //        int cnt = 0;
        //        while (!R.EndOfStream)
        //        {

        //            string s = R.ReadLine();
        //            string[] w = s.Split(',');
        //            foreach (string _w in w)
        //            {
        //                if (_w.Trim().Length > 0)
        //                {
        //                    a.Add(Convert.ToByte(_w.Trim(), 16));
        //                    cnt++;
        //                }
        //            }

        //        }
        //        R.Close();
        //    }
        //    return a.ToArray();
        //}
        //private static byte[] Get4()
        //{
        //    StreamReader reader = new StreamReader(@"Image.txt", false);
            
           
        //    var bytes = default(byte[]);
        //    using (var memstream = new MemoryStream()) 
        //    { 
        //        var buffer = new byte[512]; 
        //        var bytesRead = default(int); 
        //        while ((bytesRead = reader.BaseStream.Read(buffer, 0, buffer.Length)) > 0)   
        //            memstream.Write(buffer, 0, bytesRead);
        //        bytes = memstream.ToArray(); 
        //    }

        //    reader.Close();

        //    return bytes;
            
        //}

        //private static string Get3()
        //{
        //    StreamReader W = new StreamReader(@"Image.txt", false);
        //    string TestAnsiImage = W.ReadToEnd();
        //    W.Close();
        //    return TestAnsiImage;
            
        //}

        //private static void Save(string TestAnsiImage)
        //{
        //    StreamWriter W = new StreamWriter(@"Image.txt", false);
        //    W.Write(TestAnsiImage);
        //    W.Close();
        //}

        //private static string Get2()
        //{
        //    string s = "";

        //    using (StreamReader R = new StreamReader(@"TextFile1.txt"))
        //    {
        //        int cnt = 0;
        //        while (!R.EndOfStream)
        //        {

        //            string _s = R.ReadLine();
        //            string[] w = _s.Split(',');
        //            foreach (string _w in w)
        //            {

        //                if (_w.Trim().Length > 0)
        //                {
        //                    s = s + Char.ConvertFromUtf32(Convert.ToInt32(_w.Trim(), 16)); ;
        //                    cnt++;
        //                }
        //            }

        //        }
        //        R.Close();
        //    }
        //    return s;
        //}

        //private static char[] Get()
        //{
        //    char[] c = new char[79336] ;

        //    using(StreamReader R = new StreamReader(@"HexBytes"))
        //    {
        //        int cnt = 0;
        //        while (!R.EndOfStream)
        //        {

        //            string s = R.ReadLine();
        //            string[] w = s.Split(','); 
        //            foreach(string _w in w)
        //            {
        //                c[cnt] = _w[0];
        //                cnt++;
        //            }
                
        //        }
        //        R.Close();
        //    }
        //    return c;
        //}
    }
}
