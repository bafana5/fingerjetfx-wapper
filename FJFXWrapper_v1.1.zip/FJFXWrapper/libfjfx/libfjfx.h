// libfjfx.h

#pragma once

using namespace System;

namespace libfjfx {

	public ref class Class1
	{
		// TODO: Add your methods for this class here.
	};
}
