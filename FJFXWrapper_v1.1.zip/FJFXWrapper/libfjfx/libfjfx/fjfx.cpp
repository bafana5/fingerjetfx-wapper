/*
    FingerJetFX OSE -- Fingerprint Feature Extractor, Open Source Edition

    Copyright (c) 2011 by DigitalPersona, Inc. All rights reserved.

    DigitalPersona, FingerJet, and FingerJetFX are registered trademarks 
    or trademarks of DigitalPersona, Inc. in the United States and other
    countries.

    FingerJetFX OSE is open source software that you may modify and/or
    redistribute under the terms of the GNU Lesser General Public License
    as published by the Free Software Foundation, either version 3 of the 
    License, or (at your option) any later version, provided that the 
    conditions specified in the COPYRIGHT.txt file provided with this 
    software are met.
 
    For more information, please visit digitalpersona.com/fingerjetfx.
*/ 
/*
      LIBRARY: fjfx - Fingerprint Feature Extractor

      ALGORITHM:      Alexander Ivanisov
                      Yi Chen
                      Salil Prabhakar
      IMPLEMENTATION: Alexander Ivanisov
                      Jacob Kaminsky
                      Lixin Wei
      DATE:           11/08/2011
*/

#include <string.h>
#include "fjfx.h"
#include "FRFXLL.h"

	

#define CBEFF (0x00330502)
#define Check(x, err) { if ((x) < FRFXLL_OK) return err; }
#define CheckFx(x)    Check(x, FJFX_FAIL_EXTRACTION_UNSPEC);



struct dpHandle 
{
  FRFXLL_HANDLE h;

  dpHandle(FRFXLL_HANDLE _h = NULL) : h(_h) {}

  ~dpHandle() 
  {
    if (h)
      Close();
  }

 FRFXLL_RESULT Close() 
  {
    FRFXLL_RESULT rc = FRFXLL_OK;
    if (h) {
      rc = FRFXLLCloseHandle(h);
    }
    h = NULL;
    return rc;
  }

  operator FRFXLL_HANDLE() const  { return h; }
  FRFXLL_HANDLE* operator &()     { return &h; }
};





namespace libFjfx
{
	
	
public ref class Result
{

private:
	Result(){}
	int _i;int _l;
	unsigned char* v;
	
public: 
	
	Result(int i, unsigned char* data,int l)
	{
	
			_i=i;_l=l;
			v=new  unsigned char[l];
			for(int k=0;k<l;k++)
			{
				v[k]=( unsigned char) *(data+k);
			}	
			
		
	}
	int GetResult(){return _i;}
	array<System::Byte>^   GetData()
	 {

		  //array<System::Byte>^ arr = gcnew array<System::Byte>(sizeof v);    
		  array<System::Byte>^ arr = gcnew array<System::Byte>(_l);    
		  System::Runtime::InteropServices::Marshal::Copy((System::IntPtr)v, arr, 0, arr->Length);    
		  return arr; 
		
	 }
	int GetLength(){return _l;}

};
public ref class ISO_ANSI_PARAM
{
		unsigned int _finger_quality,_finger_position,_impression_type,_viewNumber,_rotation;
		ISO_ANSI_PARAM(){}
public:
		ISO_ANSI_PARAM( int finger_quality, int finger_position, int impression_type, int viewNumber, int rotation)
		{
				_finger_quality=finger_quality;
				_finger_position=finger_position;
				_impression_type=impression_type;
				_viewNumber=viewNumber;
			    _rotation=rotation;;
				
				
		}
		ISO_ANSI_PARAM( int finger_quality, int finger_position, int impression_type)
		{
				_finger_quality=finger_quality;
				_finger_position=finger_position;
				_impression_type=impression_type;
				_viewNumber=0;
			    _rotation=0;
				
		}

		 int get_finger_quality(){return _finger_quality;}
		 int get_finger_position(){return _finger_position;}
		 int get_impression_type(){return _impression_type;}
		 int get_rotation(){return _rotation;}
		 int get_viewNumber(){return _viewNumber;}
		
  
};

public ref class FJFXWrapper
{
  /*  libFjfx::Result^ libFjfx::clsFJFX::_fjfx_create_fmd_from_raw(
	  System::String ^raw_image  ,
	  const unsigned int dpi,
	  const unsigned int height,
	  const unsigned int width,
	  const unsigned int output_format
	
	) ;
	
	
	 libFjfx::Result^ libFjfx::clsFJFX::__fjfx_create_fmd_from_raw(
	 array<System::Byte> ^raw_image  ,
	  const unsigned int dpi,
	  const unsigned int height,
	  const unsigned int width,
	  const unsigned int output_format
	
	) ;
	 int fjfx_create_fmd_from_raw(
		  const void *raw_image,
		  const unsigned int dpi,
		  const unsigned int height,
		  const unsigned int width,
		  const unsigned int output_format,
		  void   *fmd,
		  unsigned int *size_of_fmd_ptr); 
	*/
	private:
	  int fjfx_get_pid(unsigned int *feature_extractor);
	  int _fjfx_create_fmd_from_raw(const void *raw_image,const unsigned int dpi,const unsigned int output_format,void   *fmd,unsigned int *size_of_fmd_ptr,libFjfx::ISO_ANSI_PARAM^ param) ;
      int _fjfx_create_fmd_from_raw(const void *raw_image,const unsigned int dpi,const unsigned int width,const unsigned int height,const unsigned int output_format,void   *fmd,unsigned int *size_of_fmd_ptr,libFjfx::ISO_ANSI_PARAM^ param) ;
	

	public:
		FJFXWrapper();
        libFjfx::Result^ CreateFeatureSetFromRaw(array<System::Byte>  ^raw_image,const unsigned int dpi,const unsigned int width,const unsigned int height,const unsigned int output_format,libFjfx::ISO_ANSI_PARAM^ param); 
		libFjfx::Result^ CreateFeatureSetFromRaw(array<System::Byte>  ^raw_image,const unsigned int dpi,const unsigned int output_format,libFjfx::ISO_ANSI_PARAM^ param); 
	  
        libFjfx::Result^ CreateFeatureSetFromRaw(array<System::Byte>  ^raw_image,const unsigned int dpi,const unsigned int output_format);
        libFjfx::Result^ CreateFeatureSetFromRaw(array<System::Byte>  ^raw_image,const unsigned int dpi,const unsigned int width,const unsigned int height,const unsigned int output_format);
        
        libFjfx::Result^ CreateANSIFeatureSetFromRaw(array<System::Byte>  ^raw_image,const unsigned int dpi,const unsigned int width,const unsigned int height,libFjfx::ISO_ANSI_PARAM^ param); 
        libFjfx::Result^ CreateANSIFeatureSetFromRaw(array<System::Byte>  ^raw_image,const unsigned int dpi,libFjfx::ISO_ANSI_PARAM^ param); 
	    
        libFjfx::Result^ CreateANSIFeatureSetFromRaw(array<System::Byte>  ^raw_image,const unsigned int dpi,const unsigned int width,const unsigned int height);
        libFjfx::Result^ CreateANSIFeatureSetFromRaw(array<System::Byte>  ^raw_image,const unsigned int dpi);
		
        libFjfx::Result^ CreateISOFeatureSetFromRaw(array<System::Byte>  ^raw_image,const unsigned int dpi,const unsigned int width,const unsigned int height,libFjfx::ISO_ANSI_PARAM^ param); 
        libFjfx::Result^ CreateISOFeatureSetFromRaw(array<System::Byte>  ^raw_image,const unsigned int dpi,libFjfx::ISO_ANSI_PARAM^ param); 
	    
        libFjfx::Result^ CreateISOFeatureSetFromRaw(array<System::Byte>  ^raw_image,const unsigned int dpi,const unsigned int width,const unsigned int height);
        libFjfx::Result^ CreateISOFeatureSetFromRaw(array<System::Byte>  ^raw_image,const unsigned int dpi);
 


};
libFjfx::Result^ libFjfx::FJFXWrapper::CreateFeatureSetFromRaw(array<System::Byte>  ^raw_image,const unsigned int dpi,const unsigned int width,const unsigned int height,const unsigned int output_format,libFjfx::ISO_ANSI_PARAM^ param) 
{
		unsigned char data[34 + 256 * 6];
		unsigned int f;

		unsigned char* buffer;
		buffer=new  unsigned char[raw_image->Length];

		//System::Runtime::InteropServices::Marshal::Copy(raw_image,0, (System::IntPtr) buffer,raw_image->Length);   
		for(int p=0;p<raw_image->Length;p++)
		{
			buffer[p]=raw_image[p];
		}

		int i=_fjfx_create_fmd_from_raw(buffer,
										dpi,width,height,output_format,
										data,&f,param);

		libFjfx::Result^ R= gcnew libFjfx::Result(i,data,f);


		return R;



}
libFjfx::Result^ libFjfx::FJFXWrapper::CreateFeatureSetFromRaw(array<System::Byte>  ^raw_image,const unsigned int dpi,const unsigned int output_format,libFjfx::ISO_ANSI_PARAM^ param) 
{
		unsigned char data[34 + 256 * 6];
		unsigned int f;

		unsigned char* buffer;
		buffer=new  unsigned char[raw_image->Length];

		//System::Runtime::InteropServices::Marshal::Copy(raw_image,0, (System::IntPtr) buffer,raw_image->Length);   
		for(int p=0;p<raw_image->Length;p++)
		{
			buffer[p]=raw_image[p];
		}

		int i=_fjfx_create_fmd_from_raw(buffer,
										dpi,output_format,
										data,&f,param);

		libFjfx::Result^ R= gcnew libFjfx::Result(i,data,f);


		return R;



}

int libFjfx::FJFXWrapper::_fjfx_create_fmd_from_raw(
	  const void *raw_image,
	  const unsigned int dpi,const unsigned int width,const unsigned int height,
	  const unsigned int output_format,
	  void   *fmd,
	  unsigned int *size_of_fmd_ptr,
	  libFjfx::ISO_ANSI_PARAM^ param
	) 
{




FRFXLL_DATA_TYPE dt = 0;
size_t size = size_of_fmd_ptr ? *size_of_fmd_ptr : FJFX_FMD_BUFFER_SIZE;
const unsigned char *  image=reinterpret_cast<const unsigned char *> (raw_image);
FRFXLL_HANDLE hCtx = NULL, hFeatureSet = NULL;
unsigned char * tmpl = reinterpret_cast<unsigned char *>(fmd);








if (fmd == NULL)       return FJFX_FAIL_EXTRACTION_UNSPEC;
if (raw_image == NULL) return FJFX_FAIL_EXTRACTION_BAD_IMP;
if (width > 2000 || height > 2000)                         return FJFX_FAIL_IMAGE_SIZE_NOT_SUP;
if (dpi < 300 || dpi > 1024)                               return FJFX_FAIL_IMAGE_SIZE_NOT_SUP;
if (width * 500 < 150 * dpi  || width * 500 > 812 * dpi)   return FJFX_FAIL_IMAGE_SIZE_NOT_SUP; // in range 0.3..1.62 in
if (height * 500 < 150 * dpi || height * 500 > 1000 * dpi) return FJFX_FAIL_IMAGE_SIZE_NOT_SUP; // in range 0.3..2.0 in
if (size < FJFX_FMD_BUFFER_SIZE)                           return FJFX_FAIL_OUTPUT_BUFFER_IS_TOO_SMALL;

switch (output_format) 
{
		case FJFX_FMD_ANSI_378_2004:    dt = FRFXLL_DT_ANSI_FEATURE_SET; break;
		case FJFX_FMD_ISO_19794_2_2005: dt = FRFXLL_DT_ISO_FEATURE_SET; break;
		default:return FJFX_FAIL_INVALID_OUTPUT_FORMAT;
}
 

CheckFx( FRFXLLCreateLibraryContext(&hCtx) );
FRFXLL_RESULT RESULT=FRFXLLCreateFeatureSetFromRaw(hCtx,  image+ 36 + 14, sizeof(image) - 36 - 14, 
												  width, height, dpi, 0, &hFeatureSet);


 switch ( RESULT ) 
 {
		case FRFXLL_OK: break;
		case FRFXLL_ERR_FB_TOO_SMALL_AREA:return FJFX_FAIL_EXTRACTION_BAD_IMP;
		default: return FJFX_FAIL_EXTRACTION_UNSPEC;
 }
 
 



if(param!=nullptr)
{
	unsigned int dpcm = (dpi * 100 + 50) / 254;
 const FRFXLL_OUTPUT_PARAM_ISO_ANSI _param={sizeof(FRFXLL_OUTPUT_PARAM_ISO_ANSI), CBEFF,param->get_finger_position(), param->get_viewNumber(), dpcm, dpcm, width, height,param->get_rotation(), param->get_finger_quality(),param->get_impression_type()};
 CheckFx( FRFXLLExport(hFeatureSet, dt, &_param, tmpl, &size));

}
else
{
 CheckFx( FRFXLLExport(hFeatureSet, dt, NULL, tmpl, &size));
}

FRFXLLCloseHandle(hFeatureSet);

if (size_of_fmd_ptr) *size_of_fmd_ptr = size;
return FJFX_SUCCESS;

}

int libFjfx::FJFXWrapper::_fjfx_create_fmd_from_raw(
	  const void *raw_image,
	  const unsigned int dpi,
	  const unsigned int output_format,
	  void   *fmd,
	  unsigned int *size_of_fmd_ptr,
	  libFjfx::ISO_ANSI_PARAM^ param
	) 
{




FRFXLL_DATA_TYPE dt = 0;
size_t size = size_of_fmd_ptr ? *size_of_fmd_ptr : FJFX_FMD_BUFFER_SIZE;
const unsigned char *  image=reinterpret_cast<const unsigned char *> (raw_image);
FRFXLL_HANDLE hCtx = NULL, hFeatureSet = NULL;
unsigned char * tmpl = reinterpret_cast<unsigned char *>(fmd);


#define _width(_image) (_image[36 + 14 - 5] << 8) | (_image[36 + 14 - 4])
#define _height(_image) (_image[36 + 14 - 3] << 8) | (_image[36 + 14 - 2])
		int width=_width(image);
		int height=_height(image);
#undef _height
#undef _width





if (fmd == NULL)       return FJFX_FAIL_EXTRACTION_UNSPEC;
if (raw_image == NULL) return FJFX_FAIL_EXTRACTION_BAD_IMP;
if (width > 2000 || height > 2000)                         return FJFX_FAIL_IMAGE_SIZE_NOT_SUP;
if (dpi < 300 || dpi > 1024)                               return FJFX_FAIL_IMAGE_SIZE_NOT_SUP;
if (width * 500 < 150 * dpi  || width * 500 > 812 * dpi)   return FJFX_FAIL_IMAGE_SIZE_NOT_SUP; // in range 0.3..1.62 in
if (height * 500 < 150 * dpi || height * 500 > 1000 * dpi) return FJFX_FAIL_IMAGE_SIZE_NOT_SUP; // in range 0.3..2.0 in
if (size < FJFX_FMD_BUFFER_SIZE)                           return FJFX_FAIL_OUTPUT_BUFFER_IS_TOO_SMALL;

switch (output_format) 
{
		case FJFX_FMD_ANSI_378_2004:    dt = FRFXLL_DT_ANSI_FEATURE_SET; break;
		case FJFX_FMD_ISO_19794_2_2005: dt = FRFXLL_DT_ISO_FEATURE_SET; break;
		default:return FJFX_FAIL_INVALID_OUTPUT_FORMAT;
}
 

CheckFx( FRFXLLCreateLibraryContext(&hCtx) );
FRFXLL_RESULT RESULT=FRFXLLCreateFeatureSetFromRaw(hCtx,  image+ 36 + 14, sizeof(image) - 36 - 14, 
												  width, height, dpi, 0, &hFeatureSet);


 switch ( RESULT ) 
 {
		case FRFXLL_OK: break;
		case FRFXLL_ERR_FB_TOO_SMALL_AREA:return FJFX_FAIL_EXTRACTION_BAD_IMP;
		default: return FJFX_FAIL_EXTRACTION_UNSPEC;
 }
 
 



if(param!=nullptr)
{
	unsigned int dpcm = (dpi * 100 + 50) / 254;
 const FRFXLL_OUTPUT_PARAM_ISO_ANSI _param={sizeof(FRFXLL_OUTPUT_PARAM_ISO_ANSI), CBEFF,param->get_finger_position(), param->get_viewNumber(), dpcm, dpcm, width, height,param->get_rotation(), param->get_finger_quality(),param->get_impression_type()};
 CheckFx( FRFXLLExport(hFeatureSet, dt, &_param, tmpl, &size));

}
else
{
 CheckFx( FRFXLLExport(hFeatureSet, dt, NULL, tmpl, &size));
}

FRFXLLCloseHandle(hFeatureSet);

if (size_of_fmd_ptr) *size_of_fmd_ptr = size;
return FJFX_SUCCESS;

}




libFjfx::Result^ libFjfx::FJFXWrapper::CreateFeatureSetFromRaw(array<System::Byte>  ^raw_image  ,
																	const unsigned int dpi,
																	const unsigned int output_format)
 {
		return CreateFeatureSetFromRaw(raw_image,dpi,output_format,nullptr);
 }

libFjfx::Result^ libFjfx::FJFXWrapper::CreateFeatureSetFromRaw(array<System::Byte>  ^raw_image  ,
																	const unsigned int dpi,const unsigned int width,const unsigned int height,
																	const unsigned int output_format)
 {
		return CreateFeatureSetFromRaw(raw_image,dpi,output_format,width,height,nullptr);
 }



 libFjfx::Result^ libFjfx::FJFXWrapper::CreateANSIFeatureSetFromRaw(array<System::Byte>  ^raw_image,const unsigned int dpi,libFjfx::ISO_ANSI_PARAM^ param)
{
	return CreateFeatureSetFromRaw(raw_image,dpi,FJFX_FMD_ANSI_378_2004,param);
}

 libFjfx::Result^ libFjfx::FJFXWrapper::CreateANSIFeatureSetFromRaw(array<System::Byte>  ^raw_image,const unsigned int dpi,const unsigned int width,const unsigned int height,libFjfx::ISO_ANSI_PARAM^ param)
{
	return CreateFeatureSetFromRaw(raw_image,dpi,width,height,FJFX_FMD_ANSI_378_2004,param);
}
 
  libFjfx::Result^ libFjfx::FJFXWrapper::CreateANSIFeatureSetFromRaw(array<System::Byte>  ^raw_image,const unsigned int dpi)
{
	return CreateFeatureSetFromRaw(raw_image,dpi,FJFX_FMD_ANSI_378_2004,nullptr);
}

 
 libFjfx::Result^ libFjfx::FJFXWrapper::CreateANSIFeatureSetFromRaw(array<System::Byte>  ^raw_image,const unsigned int dpi,const unsigned int width,const unsigned int height)
{
	return CreateFeatureSetFromRaw(raw_image,dpi,width,height,FJFX_FMD_ANSI_378_2004,nullptr);
}

 libFjfx::Result^ libFjfx::FJFXWrapper::CreateISOFeatureSetFromRaw(array<System::Byte>  ^raw_image,const unsigned int dpi,libFjfx::ISO_ANSI_PARAM^ param)
{
	return CreateFeatureSetFromRaw(raw_image,dpi,FJFX_FMD_ISO_19794_2_2005,param);
}
 libFjfx::Result^ libFjfx::FJFXWrapper::CreateISOFeatureSetFromRaw(array<System::Byte>  ^raw_image,const unsigned int dpi,const unsigned int width,const unsigned int height,libFjfx::ISO_ANSI_PARAM^ param)
{
	return CreateFeatureSetFromRaw(raw_image,dpi,width,height,FJFX_FMD_ISO_19794_2_2005,param);
}


  libFjfx::Result^ libFjfx::FJFXWrapper::CreateISOFeatureSetFromRaw(array<System::Byte>  ^raw_image,const unsigned int dpi)
{
	return CreateFeatureSetFromRaw(raw_image,dpi,FJFX_FMD_ISO_19794_2_2005,nullptr);
}
libFjfx::Result^ libFjfx::FJFXWrapper::CreateISOFeatureSetFromRaw(array<System::Byte>  ^raw_image,const unsigned int dpi,const unsigned int width,const unsigned int height)
{
	return CreateFeatureSetFromRaw(raw_image,dpi,width,height,FJFX_FMD_ISO_19794_2_2005,nullptr);
}


libFjfx::FJFXWrapper::FJFXWrapper(){}

int  libFjfx::FJFXWrapper::fjfx_get_pid(unsigned int *feature_extractor) 
{
	*feature_extractor = CBEFF;
	return FJFX_SUCCESS;
}



	//libFjfx::Result^ libFjfx::clsFJFX::_fjfx_create_fmd_from_raw(
//	 System::String  ^raw_image  ,
//	  const unsigned int dpi,
//	  const unsigned int height,
//	  const unsigned int width,
//	  const unsigned int output_format
//
//	) 
//{
// 
//
//unsigned char data[34 + 256 * 6];
//unsigned int f;
//int i= fjfx_create_fmd_from_raw(
//								( char *) System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(raw_image).ToPointer(),
//								dpi,height,width,output_format,
//								data,&f);
//libFjfx::Result^ R= gcnew libFjfx::Result(i,data,f);
//
//
//return R;
//
//
//
//}

//int libFjfx::clsFJFX::fjfx_create_fmd_from_raw(
//	  const void *raw_image,
//	  const unsigned int dpi,
//	  const unsigned int height,
//	  const unsigned int width,
//	  const unsigned int output_format,
//	  void   *fmd,
//	  unsigned int *size_of_fmd_ptr
//	) {
//	  if (fmd == NULL)       return FJFX_FAIL_EXTRACTION_UNSPEC;
//	  if (raw_image == NULL) return FJFX_FAIL_EXTRACTION_BAD_IMP;
//	  if (width > 2000 || height > 2000)                         return FJFX_FAIL_IMAGE_SIZE_NOT_SUP;
//	  if (dpi < 300 || dpi > 1024)                               return FJFX_FAIL_IMAGE_SIZE_NOT_SUP;
//	  if (width * 500 < 150 * dpi  || width * 500 > 812 * dpi)   return FJFX_FAIL_IMAGE_SIZE_NOT_SUP; // in range 0.3..1.62 in
//	  if (height * 500 < 150 * dpi || height * 500 > 1000 * dpi) return FJFX_FAIL_IMAGE_SIZE_NOT_SUP; // in range 0.3..2.0 in
//	  size_t size = size_of_fmd_ptr ? *size_of_fmd_ptr : FJFX_FMD_BUFFER_SIZE;
//	  if (size < FJFX_FMD_BUFFER_SIZE)                           return FJFX_FAIL_OUTPUT_BUFFER_IS_TOO_SMALL;
//	  FRFXLL_DATA_TYPE dt = 0;
//	  switch (output_format) {
//		case FJFX_FMD_ANSI_378_2004:    dt = FRFXLL_DT_ANSI_FEATURE_SET; break;
//		case FJFX_FMD_ISO_19794_2_2005: dt = FRFXLL_DT_ISO_FEATURE_SET; break;
//		default:
//		  return FJFX_FAIL_INVALID_OUTPUT_FORMAT;
//	  }
//	  dpHandle hContext, hFtrSet;
//	  CheckFx( FRFXLLCreateLibraryContext(&hContext) );
//	  switch ( FRFXLLCreateFeatureSetFromRaw(hContext, reinterpret_cast<const unsigned char *>(raw_image), width * height, width, height, dpi, FRFXLL_FEX_ENABLE_ENHANCEMENT, &hFtrSet ) ) {
//		case FRFXLL_OK: 
//		  break;
//		case FRFXLL_ERR_FB_TOO_SMALL_AREA:
//		  return FJFX_FAIL_EXTRACTION_BAD_IMP;
//		default: 
//		  return FJFX_FAIL_EXTRACTION_UNSPEC;
//	  }
//	 
//	  
//	  unsigned int dpcm = (dpi * 100 + 50) / 254;
//	  const unsigned char finger_quality  = 60;  // Equivalent to NFIQ value 3 
//	  const unsigned char finger_position = 0;   // Unknown finger
//	  const unsigned char impression_type = 0;   // Live-scan plain
//	  FRFXLL_OUTPUT_PARAM_ISO_ANSI param = {sizeof(FRFXLL_OUTPUT_PARAM_ISO_ANSI), CBEFF, finger_position, 0, dpcm, dpcm, width, height, 0, finger_quality, impression_type};
//	  unsigned char * tmpl = reinterpret_cast<unsigned char *>(fmd);
//	
//	  
//	  CheckFx( FRFXLLExport(hFtrSet, dt, &param, tmpl, &size) );
//	  if (size_of_fmd_ptr) *size_of_fmd_ptr = size;
//	  return FJFX_SUCCESS;
//	}
//
//libFjfx::Result^ libFjfx::clsFJFX::__fjfx_create_fmd_from_raw(
//	  array<System::Byte>  ^raw_image  ,
//	  const unsigned int dpi,
//	  const unsigned int height,
//	  const unsigned int width,
//	  const unsigned int output_format
//
//	) 
//{
//unsigned char data[34 + 256 * 6];
//unsigned int f;
//
//unsigned char* buffer;
//buffer=new  unsigned char[raw_image->Length];
//
////System::Runtime::InteropServices::Marshal::Copy(raw_image,0, (System::IntPtr) buffer,raw_image->Length);   
//for(int p=0;p<raw_image->Length;p++)
//{
//	buffer[p]=raw_image[p];
//}
//
//
//int i= fjfx_create_fmd_from_raw(
//								buffer,
//								dpi,height,width,output_format,
//								data,&f);
//libFjfx::Result^ R= gcnew libFjfx::Result(i,data,f);
//
//
//return R;
//
//
//
//}

}
