Unit tests for the Fingerprint Recognition library:

When running the applications the following output should be produced:

Running 95 tests..............................................................
...........................................OK!

The actual number of tests may vary.


