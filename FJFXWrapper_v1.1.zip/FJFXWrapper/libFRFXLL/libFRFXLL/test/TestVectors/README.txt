This directory contains test vectors and some common functions used by unit tests.
