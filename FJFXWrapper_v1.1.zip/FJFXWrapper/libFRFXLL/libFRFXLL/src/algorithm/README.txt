This folder contains the actual algorithm implementation of the fingerprint feature extractor.
