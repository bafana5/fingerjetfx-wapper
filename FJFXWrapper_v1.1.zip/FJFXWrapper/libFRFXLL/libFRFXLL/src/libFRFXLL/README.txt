This folder contains an implementation of the the wrapper library for the 
feature extraction algorithm.  The wrapper implements the FRFXLL API that handles 
platform-specific issues, like abstraction of system functions, 
object life-cycle management etc.

