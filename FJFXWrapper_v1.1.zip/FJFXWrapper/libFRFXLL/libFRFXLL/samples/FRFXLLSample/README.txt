Sample application for the DigitalPersona Fingerprint Recognition library

When running the applications the following output should be produced:
Starting tests.
Version 5.2.0.0
......
Done

